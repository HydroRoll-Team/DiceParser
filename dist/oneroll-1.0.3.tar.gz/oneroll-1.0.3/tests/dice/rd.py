import oneroll

print(oneroll.roll('2d4+2 # ddd', allow_comments=True).comment)