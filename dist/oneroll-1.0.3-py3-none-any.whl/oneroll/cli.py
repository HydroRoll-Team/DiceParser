from oneroll import roll

class Cli:
    def parser():
        while True:
            roll_result = roll(input(), allow_comments=True)
            print(roll_result)
